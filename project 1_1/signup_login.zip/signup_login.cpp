#include <iostream>
#include <stdlib.h>
#include <string>
#include "signup_login.hpp"
using namespace std;
//---------------------------
General::General(){
    users = new User*[1];
    users_len = 1;
    users_reg = 0;
}
General::~General() {
    for (int i = 0; i < users_reg; i++) {
        delete users[i];
    }
    delete[] users;  
}
void User::set_name(){
    cout << "Enter your name: ";
    getline(cin >> ws, name);
}
bool User::set_id(General &general){
    cout << "Enter your ID: ";
    getline(cin >> ws, id);
    int tmp = 0;
    while(tmp < general.users_reg){
        if(general.users[tmp++]->id== this->id)
            return false;
    }
    return true;
}
void User::set_pass(){
    cout << "Enter your password: ";
    getline(cin >> ws, password);
}
User* User::login(General &general){
    string id, password;
    cout << "Enter your id: ";
    getline(cin >> ws, id);
    cout << "Enter your password: ";
    getline(cin >> ws, password);
    for(int i = 0; i < general.users_reg; i++){
        if(general.users[i]->id == id
            && general.users[i]->password == password){
            return general.users[i]; 
        }
    }
    return nullptr;
}
Professor::Professor(){
    user_type = PROFESSOR;
    courses = new string[1];
    course_len = 1;
    size = 0;
}
Professor::~Professor(){
    delete[] courses;
}
void Professor::set_course(){
    int num;
    cout << "Enter number of courses: ";
    cin >> num;
    cout << "Enter your courses: ";
    for(int i = 0; i < num; i++){
        cin >> courses[i];
        size++;
        if(size == course_len) {
            course_len *= 2;
            string* temp = new string[course_len];
            for(int i = 0; i < size; i++) {
                temp[i] = courses[i]; 
            }
            delete[] courses; 
            courses = temp;
        }
    }
}
void Professor::signup(General &general){
    set_name();
    set_course();
    while(!set_id(general))
        cout << "Oops! ID is taken. Try different one." << endl;
    set_pass();
    cout << "Congrats:) You're successfully Signed Up as a professor"<< endl;
    general.users[general.users_reg++] = new Professor(*this);
    if(general.users_reg == general.users_len) {
        general.users_len *= 2;
        User** temp = new User*[general.users_len];
        for(int i = 0; i < general.users_reg; i++) {
            temp[i] = general.users[i];
        }
        delete[] general.users;
        general.users = temp;
    }    
}
Student::Student(){
    user_type = STUDENT;
}
void Student::set_field(){
    cout << "Enter your field of study: ";
    getline(cin >> ws, field);
}
void Student::signup(General &general){
    set_name();
    set_field();
    while(!set_id(general))
        cout << "Oops! ID is taken. Try different one." << endl;
    set_pass();
    cout << "Congrats:) You're successfully Signed Up as a student" << endl;
    general.users[general.users_reg++] = new Student(*this);
    if(general.users_reg == general.users_len) {
        general.users_len *= 2;
        User** temp = new User*[general.users_len];
        for(int i = 0; i < general.users_reg; i++) {
            temp[i] = general.users[i];
        }
        delete[] general.users;
        general.users = temp;
    }    
}


int main(){
    General general;
    do{
    int start;
    cout << "1.Sign UP   2.Login   3.Exit The Program" << endl;
    cin >> start;
    if(start == 1){
        int choice;
        cout << "Sign Up as a\n1.Professor\t2.Student" << endl;
        cin >> choice;
        if(choice == 1){
            Professor P;
            P.signup(general);
        }
        else if(choice == 2){
            Student S;
            S.signup(general);
        }
        else{
            cout << "Wrong choice :| Try again." << endl;
        }
    }
    else if(start == 2){
        User U;
        User *user = U.login(general);
        if(user == nullptr){
            cout << "User not found. Try again" << endl;
        }
        else{
            if(user->user_type == STUDENT){
                Student* S = dynamic_cast<Student*>(user);
                cout << "Hello Student" << endl;
            }
            else{
                Professor* P = dynamic_cast<Professor*>(user);
                cout << "Hello Professor" << endl;
            }
        }
    }
    else{
        break;
    }   
    }while(true);

    return 0;
}