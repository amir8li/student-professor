#include <iostream>
#include <stdlib.h>
#include <string>
using namespace std;

enum UserType {PROFESSOR, STUDENT};

class User;
class Professor;
class Student;

class General{
private:
    User **users;
    int users_len;
    int users_reg;
public:
    General();
    ~General();
    friend class Professor;
    friend class Student;
    friend class User;
};

class User{
protected:
    string name;
    string id;
    string password;
 public:
    UserType user_type;
    void set_name();
    bool set_id(General &general);
    void set_pass();
    virtual void signup(General &general){};
    User* login(General &general);
};

class Professor: public User{
private:
    string *courses;
    int course_len;
    int size;
public:
    Professor();
    ~Professor();
    void set_course();
    virtual void signup(General &general);
};

class Student: public User{
private:
    string field;
public:
    Student();
    void set_field();
    virtual void signup(General &general);
};

    