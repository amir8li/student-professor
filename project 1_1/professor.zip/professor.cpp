#include <iostream>
#include <stdlib.h>
#include <string>
#include "Project1.hpp"
using namespace std;
//--------------------------------------
General::General(){
    users = new User*[10];
    users_len = 10;
    users_reg = 0;
}
General::~General() {
    for (int i = 0; i < users_reg; i++) {
        delete users[i];
    }
    delete[] users;  
}
void User::set_name(){
    cout << "Enter your name: ";
    getline(cin >> ws, name);
    cout <<"###############################################################" << endl;
}
bool User::set_id(General &general){
    cout << "Enter your ID: ";
    getline(cin >> ws, id);
    cout <<"###############################################################" << endl;
    int tmp = 0;
    while(tmp < general.users_reg){
        if(general.users[tmp++]->id== this->id)
            return false;
    }
    return true;
}
void User::set_pass(){
    cout << "Enter your password: ";
    getline(cin >> ws, password);
    cout <<"###############################################################" << endl;
}
User* User::login(General &general){
    string id, password;
    cout << "Enter your id: ";
    getline(cin >> ws, id);
    cout << "Enter your password: ";
    getline(cin >> ws, password);
    cout <<"###############################################################" << endl;
    for(int i = 0; i < general.users_reg; i++){
        if(general.users[i]->id == id
            && general.users[i]->password == password){
            cout << "Logged In successfully" << endl;
            cout <<"###############################################################" << endl;
            return general.users[i]; 
        }
    }
    return nullptr;
}
//--------------------------------------
Exam::Exam(){
    questions = new Question[10];
    question_len = 10;
    question_size = 0;
}
Exam::~Exam(){
    delete[] questions;
}
void Exam::add(){
    if(question_size == question_len){
        question_len *= 2;
        Question* temp = new Question[question_len];
        for(int i = 0; i < question_size; i++) {
            temp[i] = questions[i]; 
        }
        delete[] questions; 
        questions = temp;
    }
    Question question;
    cout << "Text of the question?" << endl;
    getline(cin >> ws, question.text);
    cout << "The answer: ";
    cin >> question.ans;
    questions[question_size++] = question;
    cout << "Question created successfully!" << endl;
    cout <<"###############################################################" << endl;
}
void Exam::del(){
    if(question_size == 0){
        cout << "No question to remove!!" << endl;
        cout <<"###############################################################" << endl;
        return;
    }
    cout << "Which Question? ";
    int index;
    cin >> index;
    cout <<"###############################################################" << endl;
    if(index > question_size || index < 1){
        cout << "Question not found" << endl;
        cout <<"###############################################################" << endl;
    }
    else{  
        for(int i = index-1; i < question_size - 1; i++)
            questions[i] = questions[i+1];
        question_size--;
        cout << "Question number " << index << " successfully is removed" << endl;
        cout <<"###############################################################" << endl;
    }
}
Professor::Professor(){
    user_type = PROFESSOR;
    courses = new string[10];
    exams = new Exam[10];
    course_len = 10;
    size = 0;
    exam_len = 10;
    exam_size = 0;
}
Professor::~Professor(){
    delete[] courses;
    delete[] exams;
}
void Professor::set_course(){
    int num;
    cout << "Enter number of courses: ";
    cin >> num;
    cout << "Enter your courses: ";
    for(int i = 0; i < num; i++){
        cin >> courses[i];
        size++;
        if(size == course_len) {
            course_len *= 2;
            string* temp = new string[course_len];
            for(int i = 0; i < size; i++) {
                temp[i] = courses[i]; 
            }
            delete[] courses; 
            courses = temp;
        }
    }
    cout <<"###############################################################" << endl;
}
void Professor::signup(General &general){
    set_name();
    set_course();
    while(!set_id(general)){
        cout << "Oops! ID is taken. Try different one." << endl;
        cout <<"###############################################################" << endl;
    }
    set_pass();
    cout << "Congrats:) You're successfully Signed Up as a professor"<< endl;
    cout <<"###############################################################" << endl;
    user_index = general.users_reg;
    general.users_reg++;
    if(general.users_reg == general.users_len) {
        general.users_len *= 2;
        User** temp = new User*[general.users_len];
        for(int i = 0; i < general.users_reg; i++) {
            temp[i] = general.users[i];
        }
        delete[] general.users;
        general.users = temp;
    }    
}
int Professor::prof_menu(){
    cout << "1.Create an exam\t2.My exams\t3.Log Out" << endl;
    int choice;
    cin >> choice;
    while(choice != 1 && choice != 2 && choice != 3){
        cout << "Wrong choice :| Try again." << endl;
        cin >> choice;
    }
    cout <<"###############################################################" << endl;
    return choice;
}
Exam& Professor::create_exam(){
    if(exam_size == exam_len) {
        exam_len *= 2;
        Exam* temp = new Exam[exam_len];
        for(int i = 0; i < exam_size; i++) {
            temp[i] = exams[i]; 
        }
        delete[] exams; 
        exams = temp;
    }
    Exam& exam = exams[exam_size++];
    cout << "Name of the exam: ";
    cin >> exam.name;
    string tmp = unique_code(exam.name);
    char index = user_index + 48;
    exam.code = tmp + index;
    cout << "The exam code is: " << exam.code << endl;
    cout <<"###############################################################" << endl;
    return exam;
}
bool Professor::view_exams(){
    if(exam_size == 0){
        cout << "No exam to show!" << endl;
        cout <<"###############################################################" << endl;
        return true;
    }
    for(int i = 0; i < exam_size; i++){
        cout << "-" << exams[i].name << " : " << exams[i].code << endl;
    }
    string code;
    cout << "Enter the code of the exam you want: ";
    cin >> code;
    for(int i = 0; i < exam_size; i++){
        if(exams[i].code == code){
            cout << "The name of the exam: " << exams[i].name << endl;
            if(exams[i].question_size == 0)
                cout << "Zero question" << endl;
            else{
                for(int j = 0; j < exams[i].question_size; j++){
                    cout << j+1 << "." << exams[i].questions[j].text << endl;
                    cout << "\tthe answer is: " << exams[i].questions[j].ans << endl;
                }
            }
            cout <<"###############################################################" << endl;
            return true;;
        }
    }
    return false;
}
bool Professor::prof_functionality(General &general){
    do{
        int func = prof_menu();
        if(func == 1){
            Exam &exam = create_exam();
            do{
            cout << "1.Add Question\t2.Remove Question\t3.Return to menu" << endl;
            int method;
            cin >> method;
            cout <<"###############################################################" << endl;
            if(method == 1){
                exam.add(); 
            }
            else if(method == 2){
                exam.del();
            }
            else if(method == 3){
                break;
                cout <<"###############################################################" << endl;
            }
            else{
                cout << "Wrong choice :| Try again." << endl;
                cout <<"###############################################################" << endl;
            }
            }while(true);
        }
        else if(func == 2){
            bool flag = view_exams();
            if(flag){
                while(true){
                cout << "1.Return to menu" << endl;
                int choice;
                cin >> choice;
                if(choice == 1){
                cout <<"###############################################################" << endl;
                    break;
                }
                else
                    cout << "Wrong choice :| Try again." << endl;
                cout <<"###############################################################" << endl;
                }
            }
            else{
                cout << "Wrong code!! Returning to menu." << endl;
                cout <<"###############################################################" << endl;
            }
        }
        else if(func == 3){
            general.users[user_index] = new Professor(*this);
            return true;
        }
    }while(true);
}
//--------------------------------------
Student::Student(){
    user_type = STUDENT;
}
Student::~Student(){

}
void Student::set_field(){
    cout << "Enter your field of study: ";
    getline(cin >> ws, field);
    cout <<"###############################################################" << endl;
}
void Student::signup(General &general){
    set_name();
    set_field();
    while(!set_id(general)){
        cout << "Oops! ID is taken. Try different one." << endl;
        cout <<"###############################################################" << endl;
    }
    set_pass();
    cout << "Congrats:) You're successfully Signed Up as a student" << endl;
    cout <<"###############################################################" << endl;
    user_index = general.users_reg;
    general.users_reg++;
    //general.users[general.users_reg++] = new Student(*this);
    if(general.users_reg == general.users_len) {
        general.users_len *= 2;
        User** temp = new User*[general.users_len];
        for(int i = 0; i < general.users_reg; i++) {
            temp[i] = general.users[i];
        }
        delete[] general.users;
        general.users = temp;
    }    
}


int main(){
    General general;
    do{
    cout <<"########################### WELCOME ###########################" << endl;
    int start;
    cout << "1.Sign UP   2.Login   3.Exit The Program" << endl;
    cin >> start;
    if(start == 1){
        cout <<"###############################################################" << endl;
        int choice;
        cout << "Sign Up as a\n1.Professor\t2.Student" << endl;
        cin >> choice;
        cout <<"###############################################################" << endl;
        if(choice == 1){
            Professor *P = new Professor();
            P->signup(general);
            bool Loggedout = P->prof_functionality(general);

            if(Loggedout){
                cout << "Logged out successfully" << endl;
                continue;
            }
        }
        else if(choice == 2){
            Student *S = new Student();
            S->signup(general);
        }
        else{
            cout << "Wrong choice :| Try again." << endl;
            cout <<"###############################################################" << endl;
        }
    }
    else if(start == 2){
        cout <<"###############################################################" << endl;
        User U;
        User *user = U.login(general);
        if(user == nullptr){
            cout << "User not found. Try again" << endl;
            cout <<"###############################################################" << endl;
        }
        else{
            if(user->user_type == STUDENT){
                Student* S = dynamic_cast<Student*>(user);
            }
            else{
                Professor* P = dynamic_cast<Professor*>(user);
                
                bool Loggedout = P->prof_functionality(general);
                if(Loggedout){
                    cout << "Logged out successfully" << endl;
                    continue;
                }
            }
        }
    }
    else if(start == 3){
        cout <<"######################## SEE YOU SOON #########################" << endl;
        break;
    }
    else{
        cout << "Wrong choice :| Try again." << endl; 
        cout <<"###############################################################" << endl;
    }
    }while(true);

    return 0;
}